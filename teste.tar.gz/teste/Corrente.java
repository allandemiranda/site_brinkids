public class Corrente extends ContaBancaria
{

    public Corrente(String Ncpf, String Nagencia, String Nconta, double Nsaldo)
    {
        super(Ncpf, Nagencia, Nconta, Nsaldo);      
        
    }    
    
    private boolean verificarAplicacao(double taxa){
        if(super.verificarSaldo() < taxa){
            System.out.println("Saldo de " + super.verificarSaldo() + " reais insuficiente para aplicacao");
            return false;
        } else {
            System.out.println("Saldo de " + super.verificarSaldo() + " reais suficiente para aplicacao");
            return true;
        }
    }
    
    private void aplicarTaxa(double taxa){
        if(verificarAplicacao(taxa)){
            super.efetuarSaque(38);
            System.out.println("Taxa de " + taxa + " reias aplicada");
        } else{
            System.out.println("Taxa de " + taxa + " reias nao aplicada");
        }
                
    }
    
    private void verificarSaldoDeCriacao(){
        double minimo = 50;
        if(verificarAplicacao(minimo)){
            System.out.println("Saldo minimo OK");
        } else {
            System.out.println("Saldo minimo ERRO");
        }
    }
}
