import java.util.ArrayList;

public class Lista
{
    String nome;
    ArrayList<ContaBancaria> contas = new ArrayList();
    public Lista(String Nnome)
    {
        this.nome = Nnome;
    }

    public void abrirCorrente(String Ncpf, String Nagencia, String Nconta, double Nsaldo)
    {
        ContaBancaria novaConta = new Corrente(Ncpf, Nagencia, Nconta, Nsaldo);
        contas.add(novaConta);
    }
    
    public void abrirPoupaca(String Ncpf, String Nagencia, String Nconta, double Nsaldo)
    {
        ContaBancaria novaConta = new Poupanca(Ncpf, Nagencia, Nconta, Nsaldo);
        contas.add(novaConta);
    }
    
    public void listarContas()
    {
        //for(int i=0; i<contas.size(); i++){
        //    System.out.println("Conta " + (i+1) + "-> " + contas.get(i).cpf + " * R$ " + contas.get(i).saldo);
        //}
        System.out.println(contas.get(0).verificarSaldo());
    }
}
