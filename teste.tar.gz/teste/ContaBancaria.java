
public class ContaBancaria
{
    private String cpf, agencia, conta;
    private double saldo;

    /**
     * COnstrutor para objetos da classe ContaBancaria
     */
    public ContaBancaria(String Ncpf, String Nagencia, String Nconta, double Nsaldo)
    {
        this.cpf = Ncpf;
        this.agencia = Nagencia;
        this.conta = Nconta;
        this.saldo = Nsaldo;
        
    }

    public double verificarSaldo(){
        return saldo;
    }
    
    public void efetuarDeposito(double valor){
        saldo = saldo + valor;
    }
    
    public void efetuarSaque(double valor){
        if(valor>saldo){
            System.out.println("Saldo insuficiete para operacao");
        } else {
            saldo = saldo - valor;
        }
    }
}
