public class Poupanca extends ContaBancaria
{
    
    public Poupanca(String Ncpf, String Nagencia, String Nconta, double Nsaldo)
    {
        super(Ncpf, Nagencia, Nconta, Nsaldo);        
    }

    private boolean verificarAplicacao(double taxa){
        if(super.verificarSaldo() < taxa){
            System.out.println("Saldo de " + super.verificarSaldo() + " reais insuficiente para aplicacao");
            return false;
        } else {
            System.out.println("Saldo de " + super.verificarSaldo() + " reais suficiente para aplicacao");
            return true;
        }
    }
    
    public void render(double porcentagem){
        super.efetuarDeposito((super.verificarSaldo() * 0.55)/100);
    }
    
    public void verificarSaldoDeCriacao(){
        double minimo = 100;
        if(verificarAplicacao(minimo)){
            System.out.println("Saldo minimo OK");
        } else {
            System.out.println("Saldo minimo ERRO");
        }
    }
}
